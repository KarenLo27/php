<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
<form action="calculo.php" name="calculadora" method="post">
<br>
</br>
    <td>..::CALCULADORA::..</td>
    <br>
    </br>
    <td>Por favor ingrese el primer numero: </td>
    <td><input type="number" name="uno"></td>
    </br>
    <br>
    <td>Por favor ingrese el segundo numero: </td>
    <td><input type="number" name="dos"></td>
    </br>
    <br>
    <td><input type="submit" name="suma" value="(+) SUMAR..."></td>
    </br>
    <br>
    <td><input type="submit" name="resta" value="(-) RESTA..."></td>
    </br>
    <br>
    <td><input type="submit" name="multiplicacion" value="(*) MULTIPLICAR..."></td>
    </br>
    <br>
    <td><input type="submit" name="division" value="(/) DIVISION..."></td>
    </br>
    <br>
    <td><input type="submit" name="sumat" value="(Σ) SUMATORIA..."></td>
    </br>
    <br>
    <td><input type="submit" name="multiplo" value="(%) MULTIPLO..."></td>
    </br>
    <br>
    <td><input type="submit" name="factoral" value="FACTORIAL (!)..."></td>
    </br>
    <br>
    <td><input type="submit" name="tabla" value="PRESENTAR TABLA DE MULTIPLICAR (&)..."></td>
    <br>
    </br>
</body>
</html>