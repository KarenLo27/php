<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sumatoria de 2 numeros</title>
    <form method="POST" action="sumatoria-2.php" name= "frm1"
    <table>
<tr>
<td colspan="2">--SUMATORIA DE DOS NUMEROS ENTEROS--</td><br>
</tr>
<tr>
<td>Numero minimo:</td><br>
<td><input type="number" name="txtn1"></td>
</tr>
<tr>
<br>
<td>Numero maximo:</td></br>
<td><input type="number" name="txtn2"></td>
</tr>
<tr>
<br></br>
<td colpan="2"><input type="submit" name="btn1" value="CALCULAR "></td><br></br>
</tr>
    </table>
    </form>
</head>
<body>
    
</body>
</html>