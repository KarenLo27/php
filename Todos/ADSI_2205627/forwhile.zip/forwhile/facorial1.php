<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="fatorial.php">
    <title>Document</title>
</head>
<body>
<form name="tablas" action="factorial.php" method="POST"> 
    <table>
    <tr>
       </tr>
       <tr>
          <td colspan="2">  FACTORIAL DE CUALQUIER NUMERO</td>
       </tr>
       <tr>
       </tr>
       <tr>
       <td>Por favor ingrese el numero para determinar su factorial:</td> 
       <td><input type="number" name="factorial" ></td>
       </tr> 
       <tr>
         <td><input type="submit" value="Ver....">   </td>
       </tr>

     </table>
   </fieldset>
    </form>
</body>
</html>