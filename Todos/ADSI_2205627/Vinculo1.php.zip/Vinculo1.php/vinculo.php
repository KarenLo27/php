<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina uno</title>
</head>
<body>
    <h2>BIENVENIDOS</h2><br>
    <img src="" alt="">
    <h2>OPERACIONES MATEMATICAS</h2><br>
    <h2>Para escribir un programa dispondremos de una serie de operadores y funciones matemáticas, en general comunes para todos los lenguajes. El uso de estas herramientas tiene en general dos fines:

a)    Realizar operaciones matemáticas.

b)   Obtener un resultado verdadero o falso después de haber planteado una hipótesis o situación.

 </h2> <br>
 <h2>Los operadores matemáticos disponibles son los habituales para una calculadora. Para empezar, los básicos 
     suma ( + ), resta ( -), multiplicación ( * ) y división ( / ).</h2><br> 
     <img src="img/descarga.jpg" alt="ker"><br>
     <h2>EJERCICIO</h2><br>
     <h2>Escribe un programa que lea la entrada estandar de dos numeros y muestre en la salida
         estardar, su suma, resta, multiplicacion y division.</h2> <br>
     <img src="img/operacionesb.png" alt="ker"> <br>
     <h1>Ejercicio</h1>
     <img src="img/opesuma.png" alt="ker"><br><br>
     <img src="img/suma.png" alt="ker"><br><br>
     <img src="img/resultado.png" alt="ker"><br>

     

    <a href="vinculo.php">Opcion 1</a> <a href="vinculo-2.html">Opcion 2</a>  <a href="vinculo-3.php">Opcion 3</a>
    <a href="vinculo-4.php">Opcion 4</a>
</body>
</html>