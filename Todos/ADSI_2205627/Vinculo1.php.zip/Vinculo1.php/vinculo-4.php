<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h5>ARREGLOS ARRAY</h5>
    <h5>Un array es un conjunto de variables de una misma clase. 
        Se accede a cada elemento individual del array mediante un número entero 
        denominado índice. 0 es el índice o localizador del primer elemento, y n-1 
        es el índice del último elemento, siendo n la dimensión, tamaño o longitud del array. 
</h5><br>
        <img src="img/arreglo.png" alt="ker"><br>
        <h5>Como se carga un arreglo</h5>
        <h5>Una de las formas mas fáciles de cargar un arreglo (llenar), es utilizando un ciclo que recorra cada uno de sus índices, este ciclo puede ser FOR, WHILE, FOREACH, entre otros…..

Tenga en cuenta que la variable que controla el ciclo será la que representara cada uno de los índices del arreglo….
</h5><br>
<img src="img/arreglos1.jpg" alt="ker"><br>
<h5>Para acceder a los elementos del array se utilizan los corchetes [], dentro de los cuales existirá un localizador o índice que es un número entero. Además, podemos guardar valores de cualquier tipo de variable (string, entero, punto flotante, booleano) dentro de un array.

En algunos lenguajes es necesario declarar los arrays antes de poder utilizarlos, pero en PHP no es necesario. Cuando se definen elementos de un array, PHP reconoce automáticamente que se trata de un array sin necesidad de declaración previa.
</h5> <br>
<img src="img/algoritmo.jpg" alt="ker"><br>

<h5>Una de las formas mas fáciles de recorrer un arreglo con el animo de mostrar los valores almacenados en esa estructura,  es utilizando un ciclo que recorra cada uno de sus índices, este ciclo puede ser FOR, WHILE, FOREACH, entre otros…..

Tenga en cuenta que la variable que controla el ciclo será la que representara cada uno de los índices del arreglo…. Y finalmente, se debe imprimir el valor del arreglo con el comando “echo”, además de acceder al índice.
</h5> <br>
 <br>
 <h1>EJERCICIO</h1>
 <img src="img/arregl.png" alt="ker">

<a href="vinculo.php">Opcion 1</a> <a href="vinculo-2.html">Opcion 2</a>  <a href="vinculo-3.php">Opcion 3</a>
<a href="vinculo-4.php">Opcion 4</a>
</body>
</html>