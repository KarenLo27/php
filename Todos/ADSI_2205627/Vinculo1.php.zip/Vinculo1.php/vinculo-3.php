<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina 3</title>
</head>
<body>
    <h3>BIENVENIDOS A CICLOS</h3>
    <h3>El bucle, ciclo o repetición, es un segmento de un algoritmo o programa cuyas instrucciones se repiten un número determinado de veces, 
        mientras se cumple una determinada condición específica 
        (existe o es verdadera la condición).</h3> 
        <img src="img/para.jpg" alt="ker"> <br>
        <h3>En los bucles FOR, generalmente la expresión inicial se inicializa una variable que 
            se evalúa en la expresión de continuación y que se modifica en la expresión de paso, 
            como muestra el ejemplo siguiente: <br>

            <h3> EJERCICIO </h3><br>
<img src="img/for.png" alt="ker"><br>
     
 <a href="vinculo.php">Opcion 1</a> <a href="vinculo-2.html">Opcion 2</a>  <a href="vinculo-3.php">Opcion 3</a>
 <a href="vinculo-4.php">Opcion 4</a>
</body>
</html>